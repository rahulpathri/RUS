"""
Author: Samarth Tandon
Copyright (c) 2018, Docturnal Private Limited.All rights reserved.
Docturnal Private Limited and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto.  Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from Docturnal Private Limited is strictly prohibited
"""
import numpy as np
import pandas as pd
import xlsxwriter
import argparse
from scipy import stats
from scipy.signal import resample
from scipy.io import wavfile
from scipy.stats import mstats, skew, kurtosis
from python_speech_features import mfcc
import os, math, time, sys
from sympy import factorint
import wavio
import spectrograph as spec
import utils
import ntpath
import warnings
warnings.filterwarnings("ignore")
score_label = [
    'upto200HzLSUM', '200-500HzLSUM', '500-1KHzLSUM', '1K-1.5KHzLSUM', '1.5-2KHzLSUM', '2K-2.5KHzLSUM', '2.5-3KHzLSUM','3K-3.5KHzLSUM', '3.5K-4KHzLSUM', '4K-4.5KHzLSUM', '4.5K-5KHzLSUM',
    'upto200HzLmean', '200-500HzLmean', '500-1KHzLmean', '1K-1.5KHzLmean', '1.5-2KHzLmean', '2K-2.5KHzLmean','2.5-3KHzLmean', '3K-3.5KHzLmean', '3.5K-4KHzLmean','4K-4.5KHzLmean', '4.5K-5KHzLmean',
    'upto200HzLsigma', '200-500HzLsigma', '500-1KHzLsigma', '1K-1.5KHzLsigma', '1.5-2KHzLsigma', '2K-2.5KHzLsigma','2.5-3KHzLsigma', '3K-3.5KHzLsigma', '3.5K-4KHzLsigma', '4K-4.5KHzLsigma','4.5K-5KHzLsigma',
    'upto200HzLvar', '200-500HzLvar', '500-1KHzLvar', '1K-1.5KHzLvar', '1.5-2KHzLvar', '2K-2.5KHzLvar', '2.5-3KHzLvar','3K-3.5KHzLvar', '3.5K-4KHzLvar', '4K-4.5KHzLvar', '4.5K-5KHzLvar',
    'upto200HzLcofvar', '200-500HzLcofvar','500-1KHzcofLvar', '1K-1.5KHzcofLvar', '1.5-2KHzcofLvar','2K-2.5KHzcofLvar', '2.5-3KHzcofLvar', '3K-3.5KHzcofLvar','3.5K-4KHzcofLvar', '4K-4.5KHzcofLvar','4.5K-5KHzcofLvar',
    'upto200HzLtoptenamp', '200-500HzLtoptenamp','500-1KHzLtoptenamp', '1K-1.5KHzLtoptenamp', '1.5-2KHzLtoptenamp','2K-2.5KHzLtoptenamp', '2.5-3KHzLtoptenamp','3K-3.5KHzLtoptenamp', '3.5K-4KHztoptenamp', '4K-4.5KHzLtoptenamp','4.5K-5KHzLtoptenamp',

    'upto200HzZCR', '200-500HzZCR', '500-1KHzZCR', '1K-1.5KHzZCR', '1.5-2KHzZCR','2K-2.5KHzZCR', '2.5-3KHzZCR', '3K-3.5KHzZCR', '3.5K-4KHzZCR', '4K-4.5KHzZCR','4.5K-5KHzZCR',
    'upto200HzLcentroid', '200-500HzLcentroid', '500-1KHzLcentroid', '1K-1.5KHzLcentroid', '1.5-2KHzLcentroid','2K-2.5KHzLcentroid', '2.5-3KHzLcentroid', '3K-3.5KHzLcentroid', '3.5K-4KHzLcentroid', '4K-4.5KHzLcentroid','4.5K-5KHzLcentroid',
    'upto200HzLspread', '200-500Hzspread', '500-1KHzLspread', '1K-1.5KHzLspread', '1.5-2KHzLspread','2K-2.5KHzLspread', '2.5-3KHzLspread', '3K-3.5KHzLspread', '3.5K-4KHzLspread', '4K-4.5KHzLspread','4.5K-5KHzLspread',
    'upto200HzLflatness', '200-500HzLflatness', '500-1KHzLflatness', '1K-1.5KHzLflatness', '1.5-2KHzLflatness','2K-2.5KHzLflatness', '2.5-3KHzLflatness', '3K-3.5KHzLflatness', '3.5K-4KHzLflatness', '4K-4.5KHzLflatness','4.5K-5KHzLflatness',
    'upto200HzLskewness', '200-500HzLskewness', '500-1KHzLskewness', '1K-1.5KHzLskewness', '1.5-2KHzLskewness','2K-2.5KHzLskewness', '2.5-3KHzLskewness', '3K-3.5KHzLskewness', '3.5K-4KHzLskewness', '4K-4.5KHzLskewness','4.5K-5KHzLskewness',
    'upto200HzLkurtosis', '200-500HzLkurtosis', '500-1KHzLkurtosis', '1K-1.5KHzLkurtosis', '1.5-2KHzLkurtosis','2K-2.5KHzLskewness', '2.5-3KHzLkurtosis', '3K-3.5KHzLkurtosis', '3.5K-4KHzLkurtosis', '4K-4.5KHzLkurtosis','4.5K-5KHzLkurtosis',
    'upto200HzLmfcc', '200-500HzLmfcc', '500-1KHzLmfcc', '1K-1.5KHzLmfcc', '1.5-2KHzLmfcc', '2K-2.5KHzLmfcc','2.5-3KHzLmfcc', '3K-3.5KHzLmfcc', '3.5K-4KHzLmfcc', '4K-4.5KHzLmfcc', '4.5K-5KHzLmfcc',
    'upto200HzLenergy', '200-500HzLenergy', '500-1KHzLenergy', '1K-1.5KHzLenergy', '1.5-2KHzLenergy','2K-2.5KHzLenergy', '2.5-3KHzLenergy', '3K-3.5KHzLenergy', '3.5K-4KHzLenergy', '4K-4.5KHzLenergy','4.5K-5KHzLenergy',
    'upto200HzLPowergain', '200-500HzLPowergain', '500-1KHzLPowergain', '1K-1.5KHzLPowergain', '1.5-2KHzLPowergain','2K-2.5KHzLPowergain', '2.5-3KHzLPowergain', '3K-3.5KHzLPowergain', '3.5K-4KHzLPowergain', '4K-4.5KHzLPowergain','4.5K-5KHzLPowergain'
    ]

summary_var_list = ['sum', 'mean', 'sigma', 'var', 'cof_var', 'top_ten_amp','ZCR', 'spectral_centroid','spectral_spread',
                    'spectral_flatness', 'spectral_skewness', 'kurtosis', 'mfcc', 'energy','power_gain']

batch_index = ['upto200Hz', '200-500Hz', '500-1000Hz', '1000-1500Hz', '1500-2000Hz', '2000-2500Hz',
               '2500-3000Hz', '3000-3500Hz', '3500-4000Hz', '4000-4500Hz', '4500-5000Hz']


####################Spectral Flatness ############################
##################################################################
def spectral_flatness(channel):
    """
    Spectral Flatness Geometric mean Power Spectrum / airthematic mean power spectrum
    """
    Power_spectrum_ch = channel ** 2
    Gmean_Power_spectrum_Lch = mstats.gmean(Power_spectrum_ch)
    Amean_Power_spectrum_Lch = np.mean(Power_spectrum_ch)
    spectral_flatness_ch = Gmean_Power_spectrum_Lch / Amean_Power_spectrum_Lch
    return spectral_flatness_ch


def stSpectralCentroid(X, fs):
    """Computes spectral centroid of frame (given abs(FFT))"""
    ind = (np.arange(1, len(X) + 1)) * (fs/(2.0 * len(X)))

    Xt = X.copy()
    Xt = Xt / Xt.max()
    NUM = np.sum(ind * Xt)
    DEN = np.sum(Xt) + 0.00000001
    # Centroid:
    C = (NUM / DEN)
    # Normalize:
    C = C / (fs / 2.0)
    return C


def stEnergy(frame):
    """Computes signal energy of frame"""
    return np.sum(frame ** 2) / np.float64(len(frame))


def stSpectralSpred(X,fs):
    """Computes spectral spread of frame (given abs(FFT))"""
    ind = (np.arange(1, len(X) + 1)) * (fs/(2.0 * len(X)))

    Xt = X.copy()
    Xt = Xt / Xt.max()
    NUM = np.sum(ind * Xt)
    DEN = np.sum(Xt) + 0.0000000
    C = (NUM / DEN)
    # Spread:
    S = np.sqrt(np.sum(((ind - C) ** 2) * Xt) / DEN)
    S = S / (fs / 2.0)
    return  S

################### XLS Information ##############################
##################################################################
def write_bands_in_xls(band, worksheet):
    row = 0
    col = 0
    for freq in (band):
        worksheet.write(row, col, freq)
        #worksheet.write(row, col + 1, ch_1)
        row = row + 1

################### Summary Variable #############################
##################################################################
def write_sumVar_in_xls(varlist, worksheet):
    row = 1
    for var in varlist:
        for col in range(len(var)):
            worksheet.write(row, col + 1, var[col])
            col += 1
        row += 1

################### Write data on Xlsx############################
##################################################################
def write_in_xlsx(filename, bands_list, sumvar_lch, dwt_cof_list):
    workbook = xlsxwriter.Workbook(filename, {'nan_inf_to_errors': True})
    worksheet_1_0 = workbook.add_worksheet('upto200Hz')
    worksheet_1_1 = workbook.add_worksheet('200-500Hz')
    worksheet_1_2 = workbook.add_worksheet('500-1000Hz')
    worksheet_1_3 = workbook.add_worksheet('1000-1500Hz')
    worksheet_1_4 = workbook.add_worksheet('1500-2000Hz')
    worksheet_1_5 = workbook.add_worksheet('2000-2500Hz')
    worksheet_1_6 = workbook.add_worksheet('2500-3000Hz')
    worksheet_1_7 = workbook.add_worksheet('3000-3500Hz')
    worksheet_1_8 = workbook.add_worksheet('3500-4000Hz')
    worksheet_1_9 = workbook.add_worksheet('4000-4500Hz')
    worksheet_1_10 = workbook.add_worksheet('4500-5000Hz')
    worksheet_list = [worksheet_1_0, worksheet_1_1, worksheet_1_2, worksheet_1_3, worksheet_1_4, worksheet_1_5,
                      worksheet_1_6, worksheet_1_7, worksheet_1_8,
                      worksheet_1_9, worksheet_1_10]
    index = 0
    for band in bands_list:
        write_bands_in_xls(band, worksheet_list[index])
        index = index + 1

    worksheet_2_1 = workbook.add_worksheet('SummaryVar_Lchannel')
    write_sumVar_in_xls(sumvar_lch, worksheet_2_1)

    row = 1
    for var in summary_var_list:
        worksheet_2_1.write(row, 0, var)
        # worksheet_2_2.write(row, 0, var)
        row = row + 1
    col = 1
    for var in batch_index:
        worksheet_2_1.write(0, col, var)
        # worksheet_2_2.write(0, col, var)
        col = col + 1

    worksheet_3_0 = workbook.add_worksheet('Train_var')
    col = 0
    for lable_name in score_label:
        worksheet_3_0.write(0, col, lable_name)
        col += 1
    # Generate Train varibles in concatenated manner
    row = 1
    col = 0
    for var in sumvar_lch:
        for value in range(len(var)):
            worksheet_3_0.write(row, col, var[value])
            col = col + 1

    print ("Output file : {}".format(filename))
    workbook.close()


################### Zero Crossing Rate#############################
##################################################################
def zero_crossing_rate(frame):
    """Computes zero crossing rate of frame"""
    count = len(frame)
    countZ = np.sum(np.abs(np.diff(np.sign(frame)))) / 2
    return (np.float64(countZ) / np.float64(count - 1.0))


################### Split output band #############################
###################################################################
def split_output_band(ch_output):
    """split output band in frequency ranges """
    bandone = []
    subband_one = []
    bandTwo = []
    bandThree = []
    bandFour = []
    bandFive = []
    bandSix = []
    bandSeven = []
    bandEight = []
    bandNine = []
    bandTen = []

    for i in range(len(ch_output)):
        if ch_output[i,0] <= 200:
            bandone.append(ch_output[i, 1])
        elif ch_output[i,0] > 200 and ch_output[i, 0] <= 500:
            subband_one.append(ch_output[i, 1])
        elif ch_output[i,0] > 500 and ch_output[i, 0] <= 1000:
            bandTwo.append(ch_output[i, 1])
        elif ch_output[i,0] > 1000 and ch_output[i, 0] <= 1500:
            bandThree.append(ch_output[i, 1])
        elif ch_output[i,0] > 1500 and ch_output[i, 0] <= 2000:
            bandFour.append(ch_output[i, 1])
        elif ch_output[i,0] > 2000 and ch_output[i, 0] <= 2500:
            bandFive.append(ch_output[i, 1])
        elif ch_output[i,0] > 2500 and ch_output[i, 0] <= 3000:
            bandSix.append(ch_output[i, 1])
        elif ch_output[i,0] > 3000 and ch_output[i, 0] <= 3500:
            bandSeven.append(ch_output[i, 1])
        elif ch_output[i,0] > 3500 and ch_output[i, 0] <= 4000:
            bandEight.append(ch_output[i, 1])
        elif ch_output[i,0] > 4000 and ch_output[i, 0] <= 4500:
            bandNine.append(ch_output[i, 1])
        elif ch_output[i,0] > 4500 and ch_output[i, 0] <= 5000:
            bandTen.append(ch_output[i, 1])

    # Convert list to nd-array
    band_1 = np.asarray(bandone)
    sub_band_1 = np.asarray(subband_one)
    band_2 = np.asarray(bandTwo)
    band_3 = np.asarray(bandThree)
    band_4 = np.asarray(bandFour)
    band_5 = np.asarray(bandFive)
    band_6 = np.asarray(bandSix)
    band_7 = np.asarray(bandSeven)
    band_8 = np.asarray(bandEight)
    band_9 = np.asarray(bandNine)
    band_10 = np.asarray(bandTen)
    band = [band_1, sub_band_1, band_2, band_3, band_4, band_5, band_6, band_7, band_8, band_9, band_10]
    return band


def bestFFTlength(n):
    while max(factorint(n)) >= n:
        n -= 1
    print "Best fit length",n
    return n


# def Slice_wavfile(audio):
#     start_time = input("Enter start time in mili seconds: ")
#     end_time = input("Enter end time in mili seconds: ")
#     cliiped_audio = clip_wav.slice(audio, start_time, end_time)
#     return cliiped_audio

######################Extract wav features #####################
################################################################
def extract_wav_fet_onech(wav_file, spectograph=False, outdir='xlxdirectory'):
    """Main function to extract wav features """
    directory, filename = ntpath.split(wav_file)
    xlxdirectory = os.path.join(directory, outdir)
    if not os.path.isdir(xlxdirectory):
        os.mkdir(xlxdirectory)
    pathtoXl = os.path.join(xlxdirectory, filename[:-4]+'.xlsx')
    try:
        sampFreq, signal = wavfile.read(wav_file)
        duration = len(signal) / float(sampFreq)
        data_type = signal.dtype
    except:
        wav_param = wavio.read(wav_file)
        sampFreq = wav_param.rate
        signal = wav_param.data
        data_type = wav_param.data.dtype
        duration = (wav_param.data.shape[0]) / float(wav_param.rate)
    N = len(signal)
    if int(duration) == 0:
        print ("Error! in Processing File Duration {}s".format(duration))
        return
    if len(signal.shape) == 1:
        print ("wav file {} is a Single channel wavfile ".format(wav_file))
    print ("Attributes before Processing")
    print ("File Data Type:{}".format(data_type))
    print ("File Duration :{}s".format(duration))
    print ("Sampling Frequency: {}".format(sampFreq))
    print ("Channel Length: {}".format(N))

    output_file = wav_file
    start_time = time.time()

    ####### Determine pitch of signal #######
    #########################################
    #########################################
    maxFrequencyIndex = np.argmax(signal)
    maxFrequency = maxFrequencyIndex * (sampFreq / 2.0) / len(signal)
    pitch = int(round(69 + 12 * math.log(maxFrequency / 440.0, 2)))
    print ("Signal Pitch in DB :{}".format(pitch))

    ###### Normalizing the Data ############
    ########################################
    ########################################
    print ("Normalizing data ..")
    if data_type == 'int16':
        signal = signal / (2. ** 15)  # to normalize the values
    elif data_type == 'int32':
        signal = wav_param.data / (2. ** 31)
    else:
        sys.exit("No rule to handle {}".format(data_type))

    DC = signal.mean()
    MAX = (np.abs(signal)).max()
    data = (signal - DC) / (MAX + 0.0000000001)
    ################# Separation of Channels########
    ################################################
    ################################################
    left_channel = data

    print ("Warning! Downsampling to 16 KHz . Will be removed in future")
    # Down Sample to 16kHz
    targetsampFreq = 16000
    left_channel = resample(left_channel,targetsampFreq)
    print ("Sampling Frequency: {}".format(targetsampFreq))
    print ("Channel Length after downsampling:{}".format(len(left_channel)))
    ch_length = len(left_channel)  # calculate the channel length
    signal_data = np.asarray([left_channel,left_channel])

    #######Compute Fast Fourier Transform##########
    ###############################################
    ###############################################
    print ("computing FFT ...")
    fourier = np.fft.fft(signal_data,bestFFTlength(ch_length), axis=1)
    real_fourier = np.absolute(fourier).T

    left_channel_fourier = real_fourier[:, 0]
    right_channel_fourier = real_fourier[:, 1]

    # Get single side band spectrum
    left_channel_fourier_sss = left_channel_fourier[0:int(ch_length / 2) + 1]
    right_channel_fourier_sss = right_channel_fourier[0:int(ch_length / 2) + 1]

    # Rationalize for real Power for both channel
    left_channel_fourier_sss[1:-1] = 2 * left_channel_fourier_sss[1:-1]
    right_channel_fourier_sss[1:-1] = 2 * right_channel_fourier_sss[1:-1]

    # frequency vector
    f = (np.arange(0, ch_length / 2 + 1) / float(ch_length)) * float(targetsampFreq)

    # Band splitting
    ch_output = np.transpose(np.asarray((f, left_channel_fourier_sss, right_channel_fourier_sss))) # changes in python3
    bands_list = split_output_band(ch_output)

    print ("######################## Spectral Features ######################################")
    print ("Spectral Centroid")
    print ("Spectral spread")
    print ("Spectral Fatness")
    print ("Signal skewness")
    print ("Signal Kurtosis")
    print ("MFCC cooeficients")
    print ("Power Gain")
    print ("###################################################################")
    lch_kurtosis_list = []
    mfcc_var_lch_list = []
    spectral_centroid_Lch_list = []
    spectral_spread_Lch_list = []
    spectral_flatness_lch_list = []
    spectral_skewness_lch_list = []
    power_gain_list =[]
    print("computing Power gain")
    try:
        for band in bands_list:
            maxFrequencyIndex = np.argmax(band)
            maxFrequency = maxFrequencyIndex * (targetsampFreq / 2.0) / len(band)
            pitch = int(round(69 + 12 * math.log(maxFrequency / 440.0, 2)))
            power_gain_list.append(pitch)
    except:
        print("! Error in computing Power gain")

    print ("computing Spectral Centroid")
    try:
        for band in bands_list:
            spectral_centroid_Lch = stSpectralCentroid(band, targetsampFreq)
            spectral_centroid_Lch_list.append(spectral_centroid_Lch)
    except:
        print("! Error in computing Spectral Centroid")


    print "Computing Spectral spread"
    try:
        for band in bands_list:
            spectral_spread_Lch = stSpectralSpred(band,targetsampFreq)
            spectral_spread_Lch_list.append(spectral_spread_Lch)
    except:
        print ("Error in computing Spectral Spread")

    print ("computing Spectral Fatness")
    # Spectral Flatness Geometric mean Power Spectrum / airthematic mean power spectrum
    try:
        for band in bands_list:
            spectral_flatness_lch = spectral_flatness(band)
            spectral_flatness_lch_list.append(spectral_flatness_lch)
    except:
        print ("Error in computing Spectral Flatness")

    # skewness of a spectrum is the third central moment of this spectrum,
    # divided by the 1.5 power of the second central moment
    print ("Computing signal skewness")
    try:
        for band in bands_list:
            spectral_skewness_lch = skew(band)
            spectral_skewness_lch_list.append(spectral_skewness_lch)
    except:
        print "Error in computing signal skewness"

    # spectral kurtosis (fourth spectral moment)
    print ("computing signal Kurtosis")
    try:
        for band in bands_list:
            lch_kurtosis = kurtosis(band)
            lch_kurtosis_list.append(lch_kurtosis)
    except:
        print "Error in computing signal Kurtosis"

    # MFCC parameters
    print ("Computing MFCC cooeficients")
    try:
        for band in bands_list:
            mfcc_var_lch = np.mean(mfcc(band, targetsampFreq, nfft=1024))
            mfcc_var_lch_list.append(mfcc_var_lch)
    except:
        print("Error in computing MFCC")

    # Temporal Variables
    print ("############################other feature##################")
    print ("signal Sum")
    print ("signal mean")
    print ("signal standard deviation")
    print ("variation and coefficients of variation")
    print ("Zero crossing Rate")
    print ("top ten Amplitude")
    print ("Signal energy")
    print ("###################################################################")

    temporal_bands = []
    n_parts = 11
    bands = [int(x) for x in np.linspace(0, ch_length, n_parts + 1)[1:]]
    prev = 0
    for i, val in enumerate(bands):
        temporal_bands.append(signal_data[0,:][prev:val])
        prev = val

    LZCR_list =[]
    energy_lchBand_list = []
    Lsum_list = []
    Lmean_list = []
    Lsigma_list = []
    Lvar_list = []
    Lcof_var_list = []
    top_ten_amp_LC_list = []

    print("computing ZCR")
    try:
        for sig in temporal_bands:
            LZCR = zero_crossing_rate(sig)
            LZCR_list.append(LZCR)
    except:
        print("Error in computing ZCR")

    print("Computing Energy")
    try:
        for bands in bands_list:
            energy_perBand = stEnergy(bands)
            energy_lchBand_list.append(energy_perBand)
    except:
        print("Error in computing Energy")

    print("Computing Top ten amplitude")
    try:
        for bands in bands_list:
            temp = np.partition(bands, len(bands) - 1)
            top_ten_amp_LC = np.sum(temp[-10:].reshape(1, -1)[0])
            top_ten_amp_LC_list.append(top_ten_amp_LC)
    except:
        print("Error in computing top ten amplitude")

    print("Computing other temporal features")
    try:
        for bands in bands_list:
            Lsum = np.sum(bands)
            Lmean = np.mean(bands)
            Lsigma = np.std(bands)
            Lvariation = np.var(bands)
            Lcof_var = stats.variation(bands)

            Lsum_list.append(Lsum)
            Lmean_list.append(Lmean)
            Lsigma_list.append(Lsigma)
            Lvar_list.append(Lvariation)
            Lcof_var_list.append(Lcof_var)
    except:
        print("Error in computing other temporal features")

    summary_var_lch =\
        [Lsum_list, Lmean_list, Lsigma_list, Lvar_list, Lcof_var_list, top_ten_amp_LC_list,LZCR_list,
        spectral_centroid_Lch_list, spectral_spread_Lch_list,spectral_flatness_lch_list,
        spectral_skewness_lch_list,lch_kurtosis_list, mfcc_var_lch_list, energy_lchBand_list,power_gain_list
         ]

    dwt_cof_list = []
    # Write in xls
    print ("Feeding Data to the Excel ")
    write_in_xlsx(pathtoXl, bands_list, summary_var_lch, dwt_cof_list)
    print ("Signal_analysis.py elaspsed {} seconds\n".format(time.time() - start_time))


    trainvar_file= os.path.join(xlxdirectory,'Data.csv')
    df_train = pd.read_excel(pathtoXl, 'Train_var', index_col=None, na_values=[''])
    if os.path.isfile(trainvar_file):
        df_train.to_csv(trainvar_file,mode='a',header=False,index=False)
    else:
        df_train.to_csv(trainvar_file, mode='w',columns=df_train.columns,header=True,index=False)

    # Delete the temporary file
    if spectograph:
        print ("Generating Spectographs {}".format(output_file))
        data_directory = utils.makedir(os.path.split(output_file)[0], os.path.split(output_file)[1][:-4])
        spec.Plot_stft(output_file, data_directory)

    if os.path.split(output_file)[1].startswith('clipped_'):
        ch = input("Do you want to remove clipped version of wav file[y/n]")
        if ch == 'y' or ch == 'Y':
            print ("removing {}".format(output_file))
            os.remove(output_file)
        else:
            print("Keeping {}".format(output_file))
    return xlxdirectory


def main(args):
    wav_file = args.file
    if os.path.isfile(wav_file):
        extract_wav_fet_onech(wav_file)
    else:
        sys.exit("File Not found ")


if __name__ == '__main__':
    # Instantiate the parser
    parser = argparse.ArgumentParser(description='Extract features from wav file')
    # Required positional argument
    parser.add_argument('-f,', '--file', type=str, default=None,required=True, help='wav file path')
    parser.add_argument('-s','--spectgraph',action='store_true',default=False,help='Enable spectograph ')
    args = parser.parse_args()
    main(args)
