#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import os
import wave


# In[12]:


df = pd.read_csv("Mapping_file.csv",  index_col=0)
df



# In[61]:


def concatenate_audio_wave(audio_clip_paths, output_path):
    data = []
    for clip in audio_clip_paths:
        w = wave.open(clip, "rb")
        data.append([w.getparams(), w.readframes(w.getnframes())])
        w.close()
    output = wave.open(output_path, "wb")
    output.setparams(data[0][0])
    for i in range(len(data)):
        output.writeframes(data[i][1])
    output.close()


# In[37]:


group_df = df.groupby(['hyfe_id'])


# In[69]:


cwd = os.getcwd()
cwd

conc_folder = 'concard_wav'
CHECK_FOLDER = os.path.isdir(conc_folder)
if not CHECK_FOLDER:
    os.makedirs(conc_folder)
    print("created folder : ", conc_folder)


# In[92]:


for hyfe_id, frame in group_df:
    #print(f"First 6 entries for {hyfe_id!r}")
    #print("------------------------")
    #print(frame.head(6), end="\n\n")
    audio_clip_paths = []
    for i in range(len(frame)):
        audio_clip_paths.append(cwd+"\\share-r2d2-hyfe-cough-training-set\\"+frame.iloc[i,1].split('/')[2])
    try:
        hyfe_id = hyfe_id
        conc_wav = os.path.join(cwd, conc_folder,str(hyfe_id)+"_rec.wav")
        concatenate_audio_wave(audio_clip_paths,conc_wav)
    except FileNotFoundError:
        print("File does not exist")
    except:
        print("Other error") 

